const express = require('express');
const fs = require('fs');
const http = require('http');
const ejs = require('ejs');
const socketio = require('socket.io');
const bodyParser = require('body-parser');
const mysql = require('mysql');

let myId;
const app = express();
app.use(bodyParser.urlencoded({extended:false}));
const server = http.createServer(app).listen('3000');
const client = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '1234',
    database: 'chatting'
});

client.connect();

app.get('/chatting/:id', (req, res) => {
    myId = req.params.id;
    fs.readFile('kobayChatting.html', 'utf8', (error, data) => {
       client.query('select * from kochatting', (error, result) => {   //id 회원일때 and 상담사일때
        console.log(myId);
           res.send(ejs.render(data, {beforeMessage: result, 
            resultId: myId                                     
        }));
       });
    });
});

let currentRoom;
const io = socketio.listen(server);
io.sockets.on('connect', (socket) => {

    socket.on('joinRoom', (data) => {
        currentRoom = data;
        socket.join(data);
    });

    socket.on('message', (data) => {   //id회원일때 상담사일때
       client.query('insert into kochatting (id, message, date, room) values(?, ?, ?, ?)', [data.id, data.message, data.date, currentRoom]);  
       io.sockets.in(currentRoom).emit('message', data);
    });

    socket.on('newRoom', (data) => {
        io.sockets.emit('newRoom', data);
    });

    socket.on('messageNumber', (data) => {
        client.query('insert into kochattingNumber (room, messageNumber) values(?, ?)', [data.room, data.number])
    });

    socket.on('messageNumberUpdate', (data) => {
        client.query('update kochattingNumber set messageNumber = ? where room = ?', [data.number, data.room]);
    });

    socket.on('messageNumberUpdateTwo', (data) => {
        client.query('update kochattingNumber set messageNumber = ? where room = ?', [data.number, data.room]);
    });

    socket.on('clickMessageNumber', (data) => {
        client.query('update kochattingNumber set messageNumber = ? where room = ?', [data.number, data.room]);
    });
});

app.get('/roomInformation', (req, res) => {
    client.query('select * from kochatting', (error, result) => {
        res.send(result);
    });
})

app.get('/roomNumber', (req, res) => {
    client.query('select * from kochattingNumber', (error, result) => {
        res.send(result);
    });
})
