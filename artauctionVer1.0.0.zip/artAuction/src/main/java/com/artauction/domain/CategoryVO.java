package com.artauction.domain;

import lombok.Data;

@Data
public class CategoryVO {

	private int categoryid;
	private String categoryname;
}
