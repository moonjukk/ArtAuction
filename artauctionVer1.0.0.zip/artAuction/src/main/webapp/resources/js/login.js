
$(document).ready(function(){
  
  $('#logo').click(function(){
	   location.href = "/";
	});
  
});
